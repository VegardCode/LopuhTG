
[app]
title = MyProApp
package.name = myproapp
package.domain = org.tg.tools
source.dir = .
source.include_exts = py,png,jpg,html,css,js
version = 1.0
requirements = python3,kivy,pyjnius
orientation = portrait
permissions = INTERNET
#icon.filename =
android.arch = armeabi-v7a
fullscreen = 1
