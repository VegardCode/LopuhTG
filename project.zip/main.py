
from kivy.app import App
from kivy.uix.widget import Widget
from jnius import autoclass, cast
from android.runnable import run_on_ui_thread

# Android API
WebView = autoclass('android.webkit.WebView')
WebViewClient = autoclass('android.webkit.WebViewClient')
Intent = autoclass('content.Intent')
Uri = autoclass('net.Uri')
PythonActivity = autoclass('org.kivy.android.PythonActivity')

class MyClient(WebViewClient):
    def shouldOverrideUrlLoading(self, view, url):
        if url.startswith("http://") or url.startswith("https://"):
            # Открываем внешние ссылки в браузере системы
            activity = PythonActivity.mActivity
            intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            activity.startActivity(intent)
            return True
        return False # Локальные файлы открываем внутри

class WebApp(App):
    def build(self):
        self.create_webview()
        return Widget()

    @run_on_ui_thread
    def create_webview(self):
        activity = PythonActivity.mActivity
        webview = WebView(activity)
        webview.getSettings().setJavaScriptEnabled(True)
        webview.getSettings().setDomStorageEnabled(True)
        webview.getSettings().setAllowFileAccess(True)

        # Ставим наш крутой клиент для ссылок
        webview.setWebViewClient(MyClient())

        activity.setContentView(webview)
        webview.loadUrl('file:///android_asset/index.html')

if __name__ == '__main__':
    WebApp().run()
